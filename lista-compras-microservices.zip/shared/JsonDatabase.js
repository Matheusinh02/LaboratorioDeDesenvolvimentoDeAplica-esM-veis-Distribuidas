// Simple JSON file-based database helper
const fs = require('fs');
const path = require('path');

class JsonDatabase {
  constructor(file) {
    this.file = path.resolve(file);
    if (!fs.existsSync(this.file)) {
      fs.writeFileSync(this.file, JSON.stringify([], null, 2));
    }
  }

  read() {
    return JSON.parse(fs.readFileSync(this.file, 'utf8'));
  }

  write(data) {
    fs.writeFileSync(this.file, JSON.stringify(data, null, 2));
  }
}

module.exports = JsonDatabase;
