// Simple Service Registry with health checks
const fs = require('fs');
const path = require('path');

const REGISTRY_FILE = path.join(__dirname, 'registry.json');

function loadRegistry() {
  if (!fs.existsSync(REGISTRY_FILE)) {
    fs.writeFileSync(REGISTRY_FILE, JSON.stringify({}, null, 2));
  }
  return JSON.parse(fs.readFileSync(REGISTRY_FILE, 'utf8'));
}

function saveRegistry(data) {
  fs.writeFileSync(REGISTRY_FILE, JSON.stringify(data, null, 2));
}

function registerService(name, host, port) {
  const registry = loadRegistry();
  registry[name] = { host, port, timestamp: Date.now() };
  saveRegistry(registry);
}

function getService(name) {
  const registry = loadRegistry();
  return registry[name];
}

module.exports = { registerService, getService, loadRegistry };
