// Demo client for testing services
const axios = require('axios');

async function runDemo() {
  try {
    console.log('--- Registering User ---');
    let res = await axios.post('http://localhost:3000/api/auth/register', {
      email: 'user@example.com',
      username: 'demoUser',
      password: '123456',
      firstName: 'Demo',
      lastName: 'User'
    });
    console.log('User Registered:', res.data);

    console.log('--- Logging in ---');
    res = await axios.post('http://localhost:3000/api/auth/login', {
      email: 'user@example.com',
      password: '123456'
    });
    const token = res.data.token;
    console.log('Token:', token);

    console.log('--- Fetching Items ---');
    res = await axios.get('http://localhost:3000/api/items');
    console.log('Items:', res.data.slice(0, 3));

  } catch (err) {
    console.error(err.response ? err.response.data : err.message);
  }
}

runDemo();
